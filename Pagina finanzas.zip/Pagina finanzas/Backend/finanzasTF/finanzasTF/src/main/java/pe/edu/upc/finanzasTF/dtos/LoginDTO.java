package pe.edu.upc.finanzasTF.dtos;

public class LoginDTO {
    private String usernameO;
    private String passwordO;

    public String getUsernameO() {
        return usernameO;
    }

    public void setUsernameO(String usernameO) {
        this.usernameO = usernameO;
    }

    public String getPasswordO() {
        return passwordO;
    }

    public void setPasswordO(String passwordO) {
        this.passwordO = passwordO;
    }
}
