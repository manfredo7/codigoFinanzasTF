package pe.edu.upc.finanzasTF.dtos;

import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import pe.edu.upc.finanzasTF.entities.Letra;

import java.time.LocalDate;

public class CarteraDTO {
    private Long id;


    private LocalDate FechaCreacion;


    public CarteraDTO() {
    }

    public CarteraDTO(Long id, LocalDate fechaCreacion) {
        this.id = id;
        FechaCreacion = fechaCreacion;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getFechaCreacion() {
        return FechaCreacion;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        FechaCreacion = fechaCreacion;
    }
}
