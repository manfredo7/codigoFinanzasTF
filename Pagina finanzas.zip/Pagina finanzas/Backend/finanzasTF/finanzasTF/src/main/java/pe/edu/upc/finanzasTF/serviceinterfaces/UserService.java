package pe.edu.upc.finanzasTF.serviceinterfaces;

import org.springframework.data.repository.query.Param;
import pe.edu.upc.finanzasTF.entities.Users;

import java.util.List;

public interface UserService {
    public void insert(Users users);

    public List<Users> list();

    public void delete(Long idusers);

    public Users listarId(Long idusers);

    Boolean getdata( String username, String password);

}
