package pe.edu.upc.finanzasTF.serviceinterfaces;

import org.springframework.data.repository.query.Param;
import pe.edu.upc.finanzasTF.entities.Cartera;
import pe.edu.upc.finanzasTF.entities.Letra;

import java.util.List;

public interface CarteraService {
    public void insert(Cartera cartera);

    public List<Cartera> list();

    public void delete(Long idcartera);

    public Cartera listarId(Long idcartera);

    List<Object[]> countletras(Long idcartera);
}
