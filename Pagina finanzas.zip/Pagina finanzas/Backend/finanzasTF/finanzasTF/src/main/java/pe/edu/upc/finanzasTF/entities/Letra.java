package pe.edu.upc.finanzasTF.entities;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "letras")
public class Letra {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

@Column(name = "descripcion",length = 100,nullable = false)
    private String Descripcion;

    @Column(name = "FechaFirma",nullable = false)
private LocalDate FechaFirma;

    @Column(name = "FechaVencimiento",nullable = false)
    private LocalDate FechaVencimiento;

@Column(name = "Monto",nullable = false)
    private Double Monto;

    public Letra() {
    }

    public Letra(Long id, String descripcion, LocalDate fechaFirma, LocalDate fechaVencimiento, Double monto) {
        this.id = id;
        Descripcion = descripcion;
        FechaFirma = fechaFirma;
        FechaVencimiento = fechaVencimiento;
        Monto = monto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public LocalDate getFechaFirma() {
        return FechaFirma;
    }

    public void setFechaFirma(LocalDate fechaFirma) {
        FechaFirma = fechaFirma;
    }

    public LocalDate getFechaVencimiento() {
        return FechaVencimiento;
    }

    public void setFechaVencimiento(LocalDate fechaVencimiento) {
        FechaVencimiento = fechaVencimiento;
    }

    public Double getMonto() {
        return Monto;
    }

    public void setMonto(Double monto) {
        Monto = monto;
    }
}
