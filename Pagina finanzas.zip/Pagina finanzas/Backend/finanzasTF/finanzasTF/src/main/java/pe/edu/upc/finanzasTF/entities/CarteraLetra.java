package pe.edu.upc.finanzasTF.entities;


import jakarta.persistence.*;

@Entity
@Table(name = "carteraletra")
public class CarteraLetra {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "carteraid")
private Cartera cartera;


    @ManyToOne
    @JoinColumn(name = "letraid")
    private Letra letra;

    public CarteraLetra() {
    }

    public CarteraLetra(Long id, Cartera cartera, Letra letra) {
        this.id = id;
        this.cartera = cartera;
        this.letra = letra;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cartera getCartera() {
        return cartera;
    }

    public void setCartera(Cartera cartera) {
        this.cartera = cartera;
    }

    public Letra getLetra() {
        return letra;
    }

    public void setLetra(Letra letra) {
        this.letra = letra;
    }
}
