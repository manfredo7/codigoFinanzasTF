package pe.edu.upc.finanzasTF.dtos;

import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import pe.edu.upc.finanzasTF.entities.Cartera;
import pe.edu.upc.finanzasTF.entities.Letra;

public class CarteraLetraDTO {

    private Long id;


    private Cartera cartera;



    private Letra letra;

    public CarteraLetraDTO() {
    }

    public CarteraLetraDTO(Long id, Cartera cartera, Letra letra) {
        this.id = id;
        this.cartera = cartera;
        this.letra = letra;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cartera getCartera() {
        return cartera;
    }

    public void setCartera(Cartera cartera) {
        this.cartera = cartera;
    }

    public Letra getLetra() {
        return letra;
    }

    public void setLetra(Letra letra) {
        this.letra = letra;
    }
}
