package pe.edu.upc.finanzasTF.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.finanzasTF.entities.Cartera;
import pe.edu.upc.finanzasTF.repositories.CarteraRepository;
import pe.edu.upc.finanzasTF.serviceinterfaces.CarteraService;

import java.util.List;

@Service
public class CarteraServiceImplement implements CarteraService {
    @Autowired
    private CarteraRepository cR;


    @Override
    public void insert(Cartera cartera) {
        cR.save(cartera);
    }

    @Override
    public List<Cartera> list() {
        return cR.findAll();
    }

    @Override
    public void delete(Long idcartera) {
cR.deleteById(idcartera);
    }

    @Override
    public Cartera listarId(Long idcartera) {
        return cR.findById(idcartera).orElse(new Cartera());
    }

    @Override
    public List<Object[]> countletras(Long idcartera) {
        return cR.countletras(idcartera);
    }


}
