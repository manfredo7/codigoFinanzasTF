package pe.edu.upc.finanzasTF.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.finanzasTF.dtos.CarteraDTO;
import pe.edu.upc.finanzasTF.dtos.CarteraLetraDTO;
import pe.edu.upc.finanzasTF.entities.Cartera;
import pe.edu.upc.finanzasTF.entities.CarteraLetra;
import pe.edu.upc.finanzasTF.serviceinterfaces.CarteraLetraService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/carteraletras")
public class CateraLetraController {
    @Autowired
    private CarteraLetraService clS;

    @PostMapping
    public void insertar(@RequestBody CarteraLetraDTO carteraletraDTO){
        ModelMapper m=new ModelMapper();
        CarteraLetra te =m.map(carteraletraDTO, CarteraLetra.class);
        clS.insert(te);
    }
    //v
    @GetMapping
    public List<CarteraLetraDTO> listar(){
        return clS.list().stream().map(y->{
            ModelMapper m=new ModelMapper();
            return m.map(y,CarteraLetraDTO.class);
        }).collect(Collectors.toList());
    }
    //eli
    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") Long id){
        clS.delete(id);
    }

    @PutMapping
    public void modificar(@RequestBody CarteraLetraDTO dto) {
        ModelMapper m = new ModelMapper();
        CarteraLetra u = m.map(dto, CarteraLetra.class);
        clS.insert(u);
    }

    @GetMapping("/{id}")
    public CarteraLetraDTO listarId(@PathVariable("id") Long id) {
        ModelMapper m = new ModelMapper();
        CarteraLetraDTO dto = m.map(clS.listarId(id), CarteraLetraDTO.class);
        return dto;
    }
}
