package pe.edu.upc.finanzasTF.controllers;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.finanzasTF.dtos.CarteraDTO;
import pe.edu.upc.finanzasTF.dtos.LetraDTO;
import pe.edu.upc.finanzasTF.entities.Cartera;
import pe.edu.upc.finanzasTF.entities.Letra;
import pe.edu.upc.finanzasTF.serviceinterfaces.CarteraService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/carteras")
public class CarteraController {
    @Autowired
    private CarteraService cS;


@PostMapping("/calculotcea")
    public List<LetraDTO> listgok(@RequestParam Long idcartera){
        List<Object[]> results = cS.countletras(idcartera);
        List<LetraDTO> dtoList = new ArrayList<>();
        for (Object[] row : results) {
            LetraDTO dto = new LetraDTO();
            dto.setId(((Number) row[0]).longValue());
            dto.setFechaFirma(((LocalDate) row[1]));
            dto.setDescripcion(((String) row[2]));
            dto.setFechaVencimiento(((LocalDate) row[3]));
            dto.setMonto(((Number) row[4]).doubleValue());
            dtoList.add(dto);
        }
        return dtoList;

    }


    @PostMapping
    public void insertar(@RequestBody CarteraDTO carteraDTO){
        ModelMapper m=new ModelMapper();
        Cartera te =m.map(carteraDTO,Cartera.class);
        cS.insert(te);
    }
    //v
    @GetMapping
    public List<CarteraDTO> listar(){
        return cS.list().stream().map(y->{
            ModelMapper m=new ModelMapper();
            return m.map(y,CarteraDTO.class);
        }).collect(Collectors.toList());
    }
    //eli
    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") Long id){
        cS.delete(id);
    }

    @PutMapping
    public void modificar(@RequestBody CarteraDTO dto) {
        ModelMapper m = new ModelMapper();
        Cartera u = m.map(dto, Cartera.class);
        cS.insert(u);
    }

    @GetMapping("/{id}")
    public CarteraDTO listarId(@PathVariable("id") Long id) {
        ModelMapper m = new ModelMapper();
        CarteraDTO dto = m.map(cS.listarId(id), CarteraDTO.class);
        return dto;
    }

}
