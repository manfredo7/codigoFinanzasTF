package pe.edu.upc.finanzasTF.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.finanzasTF.entities.Users;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<Users,Long> {

    @Query(value ="SELECT EXISTS(SELECT 1 FROM users u WHERE u.username =:username AND u.password =:password)" ,nativeQuery = true)
    Boolean getdata(@Param("username") String username,@Param("password") String password);


}
