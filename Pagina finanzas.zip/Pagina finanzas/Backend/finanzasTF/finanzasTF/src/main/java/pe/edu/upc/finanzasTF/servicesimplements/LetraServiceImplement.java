package pe.edu.upc.finanzasTF.servicesimplements;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.finanzasTF.entities.Letra;
import pe.edu.upc.finanzasTF.repositories.LetraRepository;
import pe.edu.upc.finanzasTF.serviceinterfaces.LetraService;

import java.util.List;

@Service
public class LetraServiceImplement implements LetraService {
@Autowired
    private LetraRepository lR;


    @Override
    public void insert(Letra letra) {
        lR.save(letra);
    }

    @Override
    public List<Letra> list() {
        return lR.findAll();
    }

    @Override
    public void delete(Long idletra) {
lR.deleteById(idletra);
    }

    @Override
    public Letra listarId(Long idletra) {
        return lR.findById(idletra).orElse(new Letra());
    }
}
