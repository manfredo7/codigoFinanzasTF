package pe.edu.upc.finanzasTF.dtos;

import jakarta.persistence.Column;

import java.time.LocalDate;

public class LetraDTO {
    private Long id;


    private String Descripcion;


    private LocalDate FechaFirma;


    private LocalDate FechaVencimiento;

    private Double Monto;

    public LetraDTO() {
    }

    public LetraDTO(Long id, String descripcion, LocalDate fechaFirma, LocalDate fechaVencimiento, Double monto) {
        this.id = id;
        Descripcion = descripcion;
        FechaFirma = fechaFirma;
        FechaVencimiento = fechaVencimiento;
        Monto = monto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public LocalDate getFechaFirma() {
        return FechaFirma;
    }

    public void setFechaFirma(LocalDate fechaFirma) {
        FechaFirma = fechaFirma;
    }

    public LocalDate getFechaVencimiento() {
        return FechaVencimiento;
    }

    public void setFechaVencimiento(LocalDate fechaVencimiento) {
        FechaVencimiento = fechaVencimiento;
    }

    public Double getMonto() {
        return Monto;
    }

    public void setMonto(Double monto) {
        Monto = monto;
    }
}
