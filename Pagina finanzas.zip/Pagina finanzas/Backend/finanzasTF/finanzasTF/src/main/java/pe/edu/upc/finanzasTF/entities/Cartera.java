package pe.edu.upc.finanzasTF.entities;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "carteras")
public class Cartera {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "FechaCreacion",nullable = false)
    private LocalDate FechaCreacion;


    public Cartera() {
    }

    public Cartera(Long id, LocalDate fechaCreacion) {
        this.id = id;
        FechaCreacion = fechaCreacion;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getFechaCreacion() {
        return FechaCreacion;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        FechaCreacion = fechaCreacion;
    }
}
