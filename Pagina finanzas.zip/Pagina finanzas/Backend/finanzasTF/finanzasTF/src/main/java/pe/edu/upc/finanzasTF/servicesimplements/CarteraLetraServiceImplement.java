package pe.edu.upc.finanzasTF.servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.finanzasTF.entities.CarteraLetra;
import pe.edu.upc.finanzasTF.repositories.CarteraLetraRepository;
import pe.edu.upc.finanzasTF.serviceinterfaces.CarteraLetraService;

import java.util.List;


@Service
public class CarteraLetraServiceImplement implements CarteraLetraService {
    @Autowired
    private CarteraLetraRepository clR;

    @Override
    public void insert(CarteraLetra carteraLetra) {
        clR.save(carteraLetra);
    }

    @Override
    public List<CarteraLetra> list() {
        return clR.findAll();
    }

    @Override
    public void delete(Long idcarteraletra) {
clR.deleteById(idcarteraletra);
    }

    @Override
    public CarteraLetra listarId(Long idcarteraletra) {
        return clR.findById(idcarteraletra).orElse(new CarteraLetra());
    }
}
