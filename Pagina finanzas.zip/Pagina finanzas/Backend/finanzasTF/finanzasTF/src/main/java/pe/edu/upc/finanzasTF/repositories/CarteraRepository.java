package pe.edu.upc.finanzasTF.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.finanzasTF.entities.Cartera;
import pe.edu.upc.finanzasTF.entities.Letra;

import java.util.List;

@Repository
public interface CarteraRepository extends JpaRepository<Cartera,Long> {

    @Query("SELECT l.id, l.FechaFirma, l.Descripcion, l.FechaVencimiento, l.Monto \n" +
            "FROM Letra l \n" +
            "INNER JOIN CarteraLetra cl ON l.id = cl.letra.id \n" +
            "INNER JOIN Cartera c ON cl.cartera.id = c.id \n" +
            "WHERE c.id = :idcartera\n")
    List<Object[]> countletras(@Param("idcartera") Long idcartera);



}
