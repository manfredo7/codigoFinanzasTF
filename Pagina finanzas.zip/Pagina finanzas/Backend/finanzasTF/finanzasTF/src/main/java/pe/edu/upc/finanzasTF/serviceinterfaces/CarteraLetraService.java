package pe.edu.upc.finanzasTF.serviceinterfaces;

import pe.edu.upc.finanzasTF.entities.Cartera;
import pe.edu.upc.finanzasTF.entities.CarteraLetra;

import java.util.List;

public interface CarteraLetraService {

    public void insert(CarteraLetra carteraLetra);

    public List<CarteraLetra> list();

    public void delete(Long idcarteraletra);

    public CarteraLetra listarId(Long idcarteraletra);
}
