package pe.edu.upc.finanzasTF.serviceinterfaces;

import pe.edu.upc.finanzasTF.entities.Letra;
import pe.edu.upc.finanzasTF.entities.Users;

import java.util.List;

public interface LetraService {
    public void insert(Letra letra);

    public List<Letra> list();

    public void delete(Long idletra);

    public Letra listarId(Long idletra);
}
