package pe.edu.upc.finanzasTF;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanzasTfApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanzasTfApplication.class, args);
	}

}
