package pe.edu.upc.finanzasTF.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.finanzasTF.dtos.LetraDTO;
import pe.edu.upc.finanzasTF.dtos.UserDTO;
import pe.edu.upc.finanzasTF.entities.Letra;
import pe.edu.upc.finanzasTF.entities.Users;
import pe.edu.upc.finanzasTF.serviceinterfaces.LetraService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/letras")
public class LetraController {

    @Autowired
    private LetraService lS;

    @PostMapping
    public void insertar(@RequestBody LetraDTO letraDTO){
        ModelMapper m=new ModelMapper();
        Letra te =m.map(letraDTO,Letra.class);
        lS.insert(te);
    }
    //v
    @GetMapping
    public List<LetraDTO> listar(){
        return lS.list().stream().map(y->{
            ModelMapper m=new ModelMapper();
            return m.map(y,LetraDTO.class);
        }).collect(Collectors.toList());
    }
    //eli
    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") Long id){
        lS.delete(id);
    }

    @PutMapping
    public void modificar(@RequestBody LetraDTO dto) {
        ModelMapper m = new ModelMapper();
        Letra u = m.map(dto, Letra.class);
        lS.insert(u);
    }

    @GetMapping("/{id}")
    public LetraDTO listarId(@PathVariable("id") Long id) {
        ModelMapper m = new ModelMapper();
        LetraDTO dto = m.map(lS.listarId(id), LetraDTO.class);
        return dto;
    }
}
