declare module 'xirr' {
    export default function xirr(
      transactions: { amount: number; when: Date }[],
      guess?: number
    ): number;
  }
  