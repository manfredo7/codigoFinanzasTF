import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { LetraComponent } from './components/letra/letra.component';
import { CreaeditaletraComponent } from './components/letra/creaeditaletra/creaeditaletra.component';
import { CarteraComponent } from './components/cartera/cartera.component';
import { CreaeditacarteraComponent } from './components/cartera/creaeditacartera/creaeditacartera.component';
import { TCEAComponent } from './components/tcea/tcea.component';



export const routes: Routes = [
    {
        path: 'home',
        component: HomeComponent
      },
      {
        path: 'letra',
        component: LetraComponent,
        children: [
          {
            path: 'nuevo',
            component: CreaeditaletraComponent
          }
        ]
      },
      {
        path: 'cartera',
        component: CarteraComponent,
        children: [
          {
            path: 'nuevo',
            component: CreaeditacarteraComponent
          }
        ]
      },
      {
        path: 'tcea',
        component: TCEAComponent,

      }

];
