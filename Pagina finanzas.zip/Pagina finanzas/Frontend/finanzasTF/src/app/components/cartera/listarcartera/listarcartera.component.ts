import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';
import { Cartera } from '../../../models/Cartera';
import { CarteraService } from '../../../services/cartera.service';

@Component({
  selector: 'app-listarcartera',
  standalone: true,
  imports: [MatTableModule,MatButtonModule,RouterLink,MatIconModule,CommonModule],
  templateUrl: './listarcartera.component.html',
  styleUrl: './listarcartera.component.css'
})
export class ListarcarteraComponent implements OnInit{
  displayedColumns: string[] = [
    'codigo',
    'Fechacreacion',
  ];

  dataSource: MatTableDataSource<Cartera> = new MatTableDataSource();

  constructor(private cS: CarteraService) {}
  ngOnInit(): void {
    this.cS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }

}
