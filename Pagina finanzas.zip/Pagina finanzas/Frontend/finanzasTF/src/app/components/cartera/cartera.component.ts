import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { ListarcarteraComponent } from './listarcartera/listarcartera.component';

@Component({
  selector: 'app-cartera',
  standalone: true,
  imports: [RouterOutlet,ListarcarteraComponent],
  templateUrl: './cartera.component.html',
  styleUrl: './cartera.component.css'
})
export class CarteraComponent {
  constructor(public route:ActivatedRoute){}

}
