import { CommonModule, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Cartera } from '../../../models/Cartera';
import { CarteraService } from '../../../services/cartera.service';

@Component({
  selector: 'app-creaeditacartera',
  standalone: true,
  providers: [provideNativeDateAdapter()],
  imports: [MatFormFieldModule,CommonModule,NgIf,ReactiveFormsModule,MatInputModule,MatSelectModule,MatButtonModule,RouterLink,MatDatepickerModule],
  templateUrl: './creaeditacartera.component.html',
  styleUrl: './creaeditacartera.component.css'
})
export class CreaeditacarteraComponent implements OnInit{
  today?: Date;
  form: FormGroup = new FormGroup({});
  cartera: Cartera = new Cartera();

  edicionl: boolean = false;
  id: number = 0;


constructor(    private cS: CarteraService,
  private router: Router,
  private formBuilder: FormBuilder,
  private route: ActivatedRoute){this.today = new Date();}


  ngOnInit(): void {
    this.form = this.formBuilder.group({
      codigo: [''],
      fechacreacion: ['', Validators.required],

    });
  }
  aceptar(){
    if (this.form.valid) {
      this.cartera.id = this.form.value.codigo;
      this.cartera.fechaCreacion = this.form.value.fechacreacion;

      this.cS.insert(this.cartera).subscribe((data) => {
        this.cS.list().subscribe((data) => {
          this.cS.setList(data);
          console.log(data);
        });

      });
      
      this.router.navigate(['cartera']);
    }
  }

}
