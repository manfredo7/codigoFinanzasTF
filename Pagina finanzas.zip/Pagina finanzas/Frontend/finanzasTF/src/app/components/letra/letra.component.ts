import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { ListarletraComponent } from './listarletra/listarletra.component';

@Component({
  selector: 'app-letra',
  standalone: true,
  imports: [RouterOutlet,ListarletraComponent],
  templateUrl: './letra.component.html',
  styleUrl: './letra.component.css'
})
export class LetraComponent {

  constructor(public route:ActivatedRoute){}
}
