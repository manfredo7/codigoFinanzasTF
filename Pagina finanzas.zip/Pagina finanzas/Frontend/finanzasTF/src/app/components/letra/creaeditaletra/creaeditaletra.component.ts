import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Letras } from '../../../models/Letra';
import { LetraService } from '../../../services/letra.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CommonModule, NgIf } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';

@Component({
  selector: 'app-creaeditaletra',
  standalone: true,
  providers: [provideNativeDateAdapter()],
  imports: [MatFormFieldModule,CommonModule,NgIf,ReactiveFormsModule,MatInputModule,MatSelectModule,MatButtonModule,RouterLink,MatDatepickerModule],
  templateUrl: './creaeditaletra.component.html',
  styleUrl: './creaeditaletra.component.css'
})
export class CreaeditaletraComponent implements OnInit{
  today?: Date;
  form: FormGroup = new FormGroup({});
  letra: Letras = new Letras();

  edicionl: boolean = false;
  id: number = 0;

  constructor(
    private lS: LetraService,
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute
  ) {this.today = new Date();}


  ngOnInit(): void {
    this.form = this.formBuilder.group({
      codigo: [''],
      descripcion: ['', Validators.required],
      fechafirma: ['', Validators.required],
      fechavencimiento: ['', Validators.required],
      monto: ['', Validators.required]
      
 
    });
  }

  aceptar(){
    if (this.form.valid) {
      this.letra.id = this.form.value.codigo;
      this.letra.descripcion = this.form.value.descripcion;
      this.letra.fechaFirma = this.form.value.fechafirma;
      this.letra.fechaVencimiento = this.form.value.fechavencimiento;
      this.letra.monto = this.form.value.monto;

      this.lS.insert(this.letra).subscribe((data) => {
        this.lS.list().subscribe((data) => {
          this.lS.setList(data);
          console.log(data);
        });

      });
      
      this.router.navigate(['letra']);
    }
  }
}
