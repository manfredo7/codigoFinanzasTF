import { Component, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';
import { Letras } from '../../../models/Letra';
import { LetraService } from '../../../services/letra.service';
import { CommonModule } from '@angular/common'; // Importar CommonModule para usar los pipes

@Component({
  selector: 'app-listarletra',
  standalone: true,
  imports: [MatTableModule, MatButtonModule, RouterLink, MatIconModule, CommonModule], // Añadir CommonModule aquí
  templateUrl: './listarletra.component.html',
  styleUrls: ['./listarletra.component.css']
})
export class ListarletraComponent implements OnInit {
  displayedColumns: string[] = [
    'codigo',
    'descripcion',
    'fechafirma',
    'fechavencimiento',
    'monto'
  ];

  dataSource: MatTableDataSource<Letras> = new MatTableDataSource();

  constructor(private lS: LetraService) {}

  ngOnInit(): void {
    this.lS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }
}
