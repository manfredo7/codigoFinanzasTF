import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, HttpClientModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onLogin() {
    this.authService.login(this.username, this.password).subscribe(
      (response) => {
        if (response === 'true') { // Si la respuesta es true, autenticación correcta
          console.log('Login successful');
          alert('Login successful');
          this.router.navigate(['/home']); // Redirige a la página home
        } else {
          console.error('Invalid credentials');
          alert('Invalid credentials');
        }
      },
      (error) => {
        console.error('Error during login:', error);
        alert('An error occurred. Please try again.');
      }
    );
  }
}
