import { CommonModule, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterLink } from '@angular/router';
import { CarteraService } from '../../services/cartera.service';
import { Cartera } from '../../models/Cartera';
import { LetraDTO } from '../../models/LetraDTO';
import xirr from 'xirr';

@Component({
  selector: 'app-tcea',
  standalone: true,
  providers: [provideNativeDateAdapter()],
  imports: [MatFormFieldModule,CommonModule,NgIf,ReactiveFormsModule,MatInputModule,MatSelectModule,MatButtonModule,RouterLink,MatDatepickerModule,FormsModule],
  templateUrl: './tcea.component.html',
  styleUrl: './tcea.component.css'
})
export class TCEAComponent implements OnInit{
  fechaDescuento: string = this.formatDate(new Date());
  listacarteras:Cartera[]= [];

  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Añade un cero si es necesario
    const day = String(date.getDate()).padStart(2, '0'); // Añade un cero si es necesario
    return `${year}-${month}-${day}`;
  }
  tea: number = 0;
  seguro: number = 0;
  retencion: number = 0;
  otrosGastos: number = 0;
  selectedCarteraId:number=0;
  tceaCalculada: number = 0;

constructor(private cS:CarteraService){}

ngOnInit(): void {
  this.cS.list().subscribe((data) => {
    this.listacarteras = data;
  });
}

onCalculateTCEA() {
  this.cS.TCEA(this.selectedCarteraId).subscribe((data: LetraDTO[]) => {
    console.log('Letras de la cartera:', data);

    // Calcular el flujo de caja y las fechas usando `calcularValores`
    const { flujoDeCaja, fechas } = this.calcularValores(data);
    console.log('Flujo de Caja:', flujoDeCaja);
    console.log('Fechas:', fechas);

    // Preparar los datos en el formato requerido por `xirr`
    const miLista = flujoDeCaja.map((flujo, index) => ({
      amount: flujo,
      when: new Date(fechas[index])
    }));

    // Calcular la TCEA usando `xirr`
    const tceaCalculada = xirr(miLista);
    console.log('TCEA Calculada:', tceaCalculada);

    // Guardar el resultado de la TCEA calculada para mostrarlo en la interfaz
    this.tceaCalculada = tceaCalculada;
  });
}

calcularValores(letras: LetraDTO[]) {
  const fechaDescuentoDate = new Date(this.fechaDescuento);

  let valorTotalRecibir = 0; // Paso 7
  const flujoDeCaja = []; // Paso 9
  const fechas = [this.fechaDescuento]; // Paso 10 (iniciamos con la fecha de descuento solo una vez)

  letras.forEach((letra) => {
    // Paso 1: Calcular el total de días entre la fecha de vencimiento de la letra y la fecha de descuento
    const fechaVencimientoDate = new Date(letra.fechaVencimiento);
    const totalDias = (fechaVencimientoDate.getTime() - fechaDescuentoDate.getTime()) / (1000 * 3600 * 24);

    // Paso 2: Calcular la TEP para cada letra
    const tep = Math.pow(1 + this.tea / 100, totalDias / 365) - 1;

    // Paso 3: Calcular el porcentaje de descuento para cada letra
    const porcentajeDescuento = tep / (1 + tep);

    // Paso 4: Calcular el valor de descuento
    const valorDescuento = porcentajeDescuento * letra.monto;

    // Paso 5: Calcular el valor neto de cada letra
    const valorNeto = letra.monto - valorDescuento;

    // Paso 6: Calcular el valor a recibir
    const valorSeguro = (this.seguro / 100) * letra.monto;
    const valorRetencion = (this.retencion / 100) * letra.monto;
    const valorRecibir = valorNeto - valorSeguro - valorRetencion - this.otrosGastos;

    valorTotalRecibir += valorRecibir; // Acumular el valor a recibir para el paso 7

    // Paso 8: Calcular el flujo de cada letra (monto - retención)
    const flujoLetra = letra.monto - valorRetencion;

    // Paso 9: Almacenar los valores del flujo en la lista de flujo de caja
    flujoDeCaja.push(flujoLetra);

    // Paso 10: Convertir la fecha de vencimiento a string y almacenarla en la lista de fechas
    fechas.push(fechaVencimientoDate.toISOString().split('T')[0]);
  });

  // Paso 7: Agregar el valor total a recibir como el flujo de caja inicial en negativo una sola vez
  flujoDeCaja.unshift(-valorTotalRecibir);

  console.log('Fechas:', fechas);
  console.log('Flujo de Caja:', flujoDeCaja);

  // Convertimos flujoDeCaja y fechas a formato para xirr
  const miLista = flujoDeCaja.map((flujo, index) => ({
      amount: flujo,
      when: new Date(fechas[index])
  }));

  // Calculamos la TCEA usando xirr
  const tceaCalculada = xirr(miLista);
  console.log('TCEA Calculada:', tceaCalculada);

  // Guardamos la TCEA calculada para usarla en la interfaz
  this.tceaCalculada = tceaCalculada;

  return { flujoDeCaja, fechas };
}




}
