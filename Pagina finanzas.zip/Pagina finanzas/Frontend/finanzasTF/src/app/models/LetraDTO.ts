// letra-dto.model.ts
export interface LetraDTO {
    id: number;
    fechaFirma:Date // O tipo Date si es necesario
    descripcion: string;
    fechaVencimiento:Date  // O tipo Date si es necesario
    monto: number;
  }