export class Letras{
    id:number=0
    descripcion:string=""
    fechaFirma:Date=new Date(Date.now())
    fechaVencimiento:Date=new Date(Date.now())
    monto:number=0
}