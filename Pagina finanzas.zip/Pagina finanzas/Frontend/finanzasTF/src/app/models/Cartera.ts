import { Letras } from "./Letra"

export class Cartera{
    id:number=0
    fechaCreacion:Date=new Date(Date.now())




}