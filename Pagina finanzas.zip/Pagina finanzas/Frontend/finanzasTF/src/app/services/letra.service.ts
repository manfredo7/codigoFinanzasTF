import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Letras } from '../models/Letra';
import { environment } from '../../environments/environments';
import { HttpClient } from '@angular/common/http';
const base_url = environment.base;
@Injectable({
  providedIn: 'root'
})
export class LetraService {

  private url = `${base_url}/letras`;
  private listaCambio = new Subject<Letras[]>();
  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Letras[]>(this.url);
  }
  insert(e: Letras) {
    console.log('Datos enviados al backend:', e);
    return this.http.post(this.url, e);
  }
  setList(listaNueva: Letras[]) {
    this.listaCambio.next(listaNueva);
  }
  getList() {
    return this.listaCambio.asObservable()
  }

  listId(id:number){
    return this.http.get<Letras>(`${this.url}/${id}`)
  }
  update(e: Letras) {
    return this.http.put(this.url, e);
  }
  eliminar(id: number) {
    return this.http.delete(`${this.url}/${id}`);
  }
}
