import { Injectable } from '@angular/core';
import { environment } from '../../environments/environments';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { Cartera } from '../models/Cartera';
import { Letras } from '../models/Letra';
const base_url = environment.base;
@Injectable({
  providedIn: 'root'
})
export class CarteraService {

  private url = `${base_url}/carteras`;
  private listaCambio = new Subject<Cartera[]>();
  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Cartera[]>(this.url);
  }
  insert(e: Cartera) {
    console.log('Datos enviados al backend:', e);
    return this.http.post(this.url, e);
  }
  setList(listaNueva: Cartera[]) {
    this.listaCambio.next(listaNueva);
  }
  getList() {
    return this.listaCambio.asObservable()
  }

  listId(id:number){
    return this.http.get<Cartera>(`${this.url}/${id}`)
  }
  update(e: Cartera) {
    return this.http.put(this.url, e);
  }
  eliminar(id: number) {
    return this.http.delete(`${this.url}/${id}`);
  }

  TCEA(e: number):Observable<any[]> {

    return this.http.post<any[]>(`${this.url}/calculotcea?idcartera=${e}`,e);

    
  }

}
