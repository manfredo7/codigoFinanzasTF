import {
  __commonJS
} from "./chunk-WKYGNSYM.js";

// node_modules/newton-raphson-method/index.js
var require_newton_raphson_method = __commonJS({
  "node_modules/newton-raphson-method/index.js"(exports, module) {
    "use strict";
    module.exports = newtonRaphson;
    function newtonRaphson(f, fp, x0, options) {
      var x1, y, yp, tol, maxIter, iter, yph, ymh, yp2h, ym2h, h, hr, verbose, eps;
      if (typeof fp !== "function") {
        options = x0;
        x0 = fp;
        fp = null;
      }
      options = options || {};
      tol = options.tolerance === void 0 ? 1e-7 : options.tolerance;
      eps = options.epsilon === void 0 ? 2220446049250313e-31 : options.epsilon;
      maxIter = options.maxIterations === void 0 ? 20 : options.maxIterations;
      h = options.h === void 0 ? 1e-4 : options.h;
      verbose = options.verbose === void 0 ? false : options.verbose;
      hr = 1 / h;
      iter = 0;
      while (iter++ < maxIter) {
        y = f(x0);
        if (fp) {
          yp = fp(x0);
        } else {
          yph = f(x0 + h);
          ymh = f(x0 - h);
          yp2h = f(x0 + 2 * h);
          ym2h = f(x0 - 2 * h);
          yp = (ym2h - yp2h + 8 * (yph - ymh)) * hr / 12;
        }
        if (Math.abs(yp) <= eps * Math.abs(y)) {
          if (verbose) {
            console.log("Newton-Raphson: failed to converged due to nearly zero first derivative");
          }
          return false;
        }
        x1 = x0 - y / yp;
        if (Math.abs(x1 - x0) <= tol * Math.abs(x1)) {
          if (verbose) {
            console.log("Newton-Raphson: converged to x = " + x1 + " after " + iter + " iterations");
          }
          return x1;
        }
        x0 = x1;
      }
      if (verbose) {
        console.log("Newton-Raphson: Maximum iterations reached (" + maxIter + ")");
      }
      return false;
    }
  }
});

// node_modules/xirr/xirr.js
var require_xirr = __commonJS({
  "node_modules/xirr/xirr.js"(exports, module) {
    var newton = require_newton_raphson_method();
    var MILLIS_PER_DAY = 1e3 * 60 * 60 * 24;
    var DAYS_IN_YEAR = 365;
    function convert(data) {
      if (!data || !data.length || !data.forEach || data.length < 2) {
        throw new Error("Argument is not an array with length of 2 or more.");
      }
      var investments = [];
      var start = Math.floor(data[0].when / MILLIS_PER_DAY);
      var end = start;
      var minAmount = Number.POSITIVE_INFINITY;
      var maxAmount = Number.NEGATIVE_INFINITY;
      var total = 0;
      var deposits = 0;
      data.forEach(function(datum) {
        total += datum.amount;
        if (datum.amount < 0) {
          deposits += -datum.amount;
        }
        var epochDays = Math.floor(datum.when / MILLIS_PER_DAY);
        start = Math.min(start, epochDays);
        end = Math.max(end, epochDays);
        minAmount = Math.min(minAmount, datum.amount);
        maxAmount = Math.max(maxAmount, datum.amount);
        investments.push({
          amount: datum.amount,
          epochDays
        });
      });
      if (start === end) {
        throw new Error("Transactions must not all be on the same day.");
      }
      if (minAmount >= 0) {
        throw new Error("Transactions must not all be nonnegative.");
      }
      if (maxAmount < 0) {
        throw new Error("Transactions must not all be negative.");
      }
      investments.forEach(function(investment) {
        investment.years = (end - investment.epochDays) / DAYS_IN_YEAR;
      });
      return {
        total,
        deposits,
        days: end - start,
        investments,
        maxAmount
      };
    }
    function xirr(transactions, options) {
      var data = convert(transactions);
      if (data.maxAmount === 0) {
        return -1;
      }
      var investments = data.investments;
      var value = function(rate2) {
        return investments.reduce(function(sum, investment) {
          var A = investment.amount;
          var Y = investment.years;
          if (-1 < rate2) {
            return sum + A * Math.pow(1 + rate2, Y);
          } else if (rate2 < -1) {
            return sum - Math.abs(A) * Math.pow(-1 - rate2, Y);
          } else if (Y === 0) {
            return sum + A;
          } else {
            return sum;
          }
        }, 0);
      };
      var derivative = function(rate2) {
        return investments.reduce(function(sum, investment) {
          var A = investment.amount;
          var Y = investment.years;
          if (Y === 0) {
            return sum;
          } else if (-1 < rate2) {
            return sum + A * Y * Math.pow(1 + rate2, Y - 1);
          } else if (rate2 < -1) {
            return sum + Math.abs(A) * Y * Math.pow(-1 - rate2, Y - 1);
          } else {
            return sum;
          }
        }, 0);
      };
      var guess = options ? options.guess : void 0;
      if (guess && isNaN(guess)) {
        throw new Error("option.guess must be a number.");
      }
      if (!guess) {
        guess = data.total / data.deposits / (data.days / DAYS_IN_YEAR);
      }
      var rate = newton(value, derivative, guess, options);
      if (rate === false) {
        throw new Error("Newton-Raphson algorithm failed to converge.");
      }
      return rate;
    }
    module.exports = xirr;
  }
});
export default require_xirr();
//# sourceMappingURL=xirr.js.map
