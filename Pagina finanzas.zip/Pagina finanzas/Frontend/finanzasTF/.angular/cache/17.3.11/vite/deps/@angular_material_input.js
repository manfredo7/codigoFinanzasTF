import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-FNXIERXR.js";
import "./chunk-NKH6NYL5.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-ZU2GJPF3.js";
import "./chunk-GVKTVOVF.js";
import "./chunk-HEUV5EUW.js";
import "./chunk-VBIE6LKH.js";
import "./chunk-M4XJ4RAE.js";
import "./chunk-CO2UG7VT.js";
import "./chunk-WKYGNSYM.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
